
-- --------------------------------------------------------

--
-- Table structure for table `akunsiswa`
--

CREATE TABLE `akunsiswa` (
  `id` int(11) NOT NULL,
  `nisn` int(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akunsiswa`
--

INSERT INTO `akunsiswa` (`id`, `nisn`, `password`, `img`) VALUES
(1, 123456789, 'aaaa', 'ajang.jpg');
