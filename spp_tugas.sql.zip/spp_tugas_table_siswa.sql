
-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nisn` int(15) NOT NULL,
  `id_kelas` int(20) NOT NULL,
  `id_jurusan` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nama`, `nisn`, `id_kelas`, `id_jurusan`) VALUES
(1, 'Abdurahman  Jaelani', 123456789, 11, 1),
(2, 'Agil Lukman Nugraha', 123456788, 11, 1),
(3, 'Chandra Arya Djungjunan', 123456787, 11, 1),
(4, 'Agung Wira', 123456786, 11, 1),
(5, 'Derlina Tarisa ', 123456777, 11, 1),
(6, 'Dzikri Kahfi', 213241343, 8, 2);
