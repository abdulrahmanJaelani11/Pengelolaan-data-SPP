
-- --------------------------------------------------------

--
-- Table structure for table `jurusan`
--

CREATE TABLE `jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `jurusan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jurusan`
--

INSERT INTO `jurusan` (`id_jurusan`, `jurusan`) VALUES
(1, 'Rekayasa Perangkat Lunak'),
(2, 'Teknik Kendaraan Ringan Otomotif'),
(3, 'Teknik Instalasi Tenaga Listrik'),
(4, 'Teknik Informatika'),
(6, 'Teknik Sepeda Motor'),
(7, 'Software Engginer'),
(15, 'Teknik Robotika');
