
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telepon` varchar(13) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `posisi` varchar(11) NOT NULL,
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `telepon`, `password`, `posisi`, `img`) VALUES
(1, 'Abdurahman', NULL, NULL, '$2y$10$Xl5t9980tbv2ckCOEqKVDuOqjhGoatMtj/TApAHiTO6Jzy2/gRsJu', 'admin', 'default.png'),
(2, 'Agung', NULL, NULL, '$2y$10$RsCbBeMfGDo/be8Brv3rHOlrmuKZAdqzKUstKiOl8L.ULLROfRaJ.', 'petugas', 'default.png');
