
-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_siswa` int(20) DEFAULT NULL,
  `id_bulan` int(15) DEFAULT NULL,
  `nominal` varchar(100) DEFAULT NULL,
  `petugas` varchar(100) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `tgl_pembayaran` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_siswa`, `id_bulan`, `nominal`, `petugas`, `keterangan`, `tgl_pembayaran`) VALUES
(1, 1, 1, '150000', 'Abdurahman', 'LUNAS', '2022-01-16'),
(2, 1, 13, '70000', 'Abdurahman', 'BELUM LUNAS', '2022-01-16'),
(3, 1, 13, '70000', 'Abdurahman', 'BELUM LUNAS', '2022-01-02'),
(4, 1, 13, '40000', 'Abdurahman', 'BELUM LUNAS', '2022-01-16');
