
-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `kelas` varchar(100) NOT NULL,
  `NoKelas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `kelas`, `NoKelas`) VALUES
(2, 'X', 'X RPL2'),
(7, 'XI', 'XI RPL2'),
(8, 'XI', 'XI TKRO1'),
(9, 'XI', 'XI TKRO2'),
(10, 'XI ', 'XI TITL'),
(11, 'XII', 'XII RPL1'),
(12, 'XII', 'XII RPL2'),
(14, 'XII', 'XII TKRO2');
